document.addEventListener("DOMContentLoaded", () => {
    const app = document.getElementById("app");
    app.innerHTML = `
        <h1>Welcome to CADsimpleV2</h1>
        <button onclick="location.href='dispatcher.html'">Enter Dispatcher Panel</button>
    `;
});
