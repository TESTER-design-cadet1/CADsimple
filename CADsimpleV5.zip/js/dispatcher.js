document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("dispatcher-app").innerHTML += "<p>Dispatcher tools coming soon...</p>";
});
