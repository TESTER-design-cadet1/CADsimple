// js/app.js
// Entry point for app-wide logic and event binding

import supabase from '../services/supabase.js';

document.addEventListener("DOMContentLoaded", () => {
    console.log("App Initialized");
});
