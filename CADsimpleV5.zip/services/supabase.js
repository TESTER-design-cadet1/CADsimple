// services/supabase.js
// This will handle Supabase authentication and data operations

const SUPABASE_URL = "https://your-project.supabase.co";
const SUPABASE_KEY = "your-public-anon-key";

const client = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

export default client;
